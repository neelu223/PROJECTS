/* =======================================================
   FIXED LOGIN SYSTEM
   User:     user / 1234
   Executor: executor / admin
======================================================= */

function userLogin() {
    const u = document.getElementById("user-name").value.trim();
    const p = document.getElementById("user-pass").value.trim();

    if (u === "user" && p === "1234") {
        window.location.href = "user-dashboard.html";
    } else {
        alert("Incorrect username or password for user.");
    }
}

function execLogin() {
    const u = document.getElementById("exec-name").value.trim();
    const p = document.getElementById("exec-pass").value.trim();

    if (u === "executor" && p === "admin") {
        window.location.href = "exec-dashboard.html";
    } else {
        alert("Incorrect username or password for executor.");
    }
}


/* =======================================================
   VOICE INPUT (Report Page)
======================================================= */

function startVoice() {
    const textarea = document.getElementById("problem");
    if (!textarea) return;

    if (!('webkitSpeechRecognition' in window)) {
        alert("Speech recognition not supported in this browser.");
        return;
    }

    const rec = new webkitSpeechRecognition();
    rec.lang = "en-IN";

    rec.onresult = function (e) {
        const text = e.results[0][0].transcript;
        textarea.value = text;
    };

    rec.start();
}


/* =======================================================
   PHOTO UPLOAD (hidden input + button)
======================================================= */

function openPhotoUpload() {
    const input = document.getElementById("photoInput");
    const label = document.getElementById("photoName");
    if (!input || !label) return;

    input.click();

    input.onchange = function () {
        const file = this.files[0];
        if (file) {
            label.textContent = "Selected: " + file.name;
        } else {
            label.textContent = "";
        }
    };
}


/* =======================================================
   LOCATION → PLACE NAME USING NOMINATIM
======================================================= */

let placeName = "";

function getLocation() {
    const locText = document.getElementById("locationText");
    if (!locText) return;

    if (!navigator.geolocation) {
        alert("Geolocation is not supported by this browser.");
        return;
    }

    navigator.geolocation.getCurrentPosition(async pos => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;

        locText.textContent = "Detecting place...";

        try {
            const url =
                `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`;
            const res = await fetch(url, {
                headers: { "User-Agent": "JanAnurodhDemo/1.0" }
            });
            const data = await res.json();

            placeName = data.display_name || "Unknown location";
            locText.textContent = "📍 Location: " + placeName;
        } catch (err) {
            console.error(err);
            placeName = "";
            locText.textContent = "Could not fetch place name.";
        }
    }, () => {
        alert("Unable to get your location.");
    });
}


/* =======================================================
   SUBMIT REPORT (Store Ticket in localStorage)
======================================================= */

function submitReport() {
    const issueText = document.getElementById("problem")?.value.trim();
    const photoFile = document.getElementById("photoInput")?.files[0];

    if (!issueText) {
        alert("Please describe the issue before submitting.");
        return;
    }

    let photoURL = "";

if (photoFile) {
    const reader = new FileReader();
    reader.onload = function (e) {
        photoURL = e.target.result;   // base64 string

        saveTicket(issueText, photoURL);
    };
    reader.readAsDataURL(photoFile);
} else {
    saveTicket(issueText, "");
}
function saveTicket(issueText, photoURL) {
    const now = new Date();

    const ticket = {
        id: Date.now(),
        text: issueText,
        location: placeName || "Not provided",
        status: "Pending",
        photo: photoURL,           // base64 image saved permanently
        createdAt: now.toLocaleString(),
        createdAtTime: now.getTime(),
        escalated: false
    };

    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    list.push(ticket);
    localStorage.setItem("tickets", JSON.stringify(list));

    alert("Issue reported successfully!");

    window.location.href = "user-dashboard.html";
}


    const now = new Date();
    const ticket = {
        id: Date.now(),
        text: issueText,
        location: placeName || "Not provided",
        status: "Pending",        // initial state
        photo: photoURL,
        createdAt: now.toLocaleString(),
        createdAtTime: now.getTime(),
        escalated: false
    };

    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    list.push(ticket);
    localStorage.setItem("tickets", JSON.stringify(list));

    alert("Issue reported successfully!");

    // Return to user dashboard
    window.location.href = "user-dashboard.html";
}


/* =======================================================
   PAGE-SPECIFIC LOADERS
======================================================= */

document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("progressList")) {
        loadUserProgress();
    }
    if (document.getElementById("pendingList")) {
        loadPending();
    }
    if (document.getElementById("inprogList")) {
        loadInProgress();
    }
    if (document.getElementById("completedList")) {
        loadCompleted();
    }
});


/* =======================================================
   USER: PROGRESS VIEW (with 15-day escalation)
======================================================= */

function loadUserProgress() {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    const container = document.getElementById("progressList");
    if (!container) return;

    const FIFTEEN_DAYS = 15 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    let html = "";
    let anyEscalatedNow = false;

    list.forEach((t, i) => {
        let badgeClass = "";
        if (t.status === "Pending") badgeClass = "status-badge status-pending";
        else if (t.status === "In Progress") badgeClass = "status-badge status-inprogress";
        else if (t.status === "Completed") badgeClass = "status-badge status-completed";

        let escalationNote = "";

        if (t.status === "Pending" && t.createdAtTime) {
            const diff = now - t.createdAtTime;
            if (diff > FIFTEEN_DAYS) {
                if (!t.escalated) {
                    t.escalated = true;
                    anyEscalatedNow = true;
                }
                escalationNote =
                    `<div class="escalation-text">
                        This issue has been pending for more than 15 days and has been escalated.
                    </div>`;
            }
        }

        html += `
            <div class="issue-card">
                <h3>Issue ${i + 1}</h3>
                <p><b>Description:</b> ${t.text}</p>
                <p><b>Location:</b> ${t.location}</p>
                <p><b>Reported:</b> ${t.createdAt}</p>
                <p><b>Status:</b> <span class="${badgeClass}">${t.status}</span></p>
                ${t.photo ? `<img src="${t.photo}" width="120" style="border-radius:8px;margin-top:5px;">` : ""}
                ${escalationNote}
            </div>
        `;
    });

    // Save back in case some tickets were escalated just now
    localStorage.setItem("tickets", JSON.stringify(list));

    if (anyEscalatedNow) {
        alert("One or more of your issues have been pending for more than 15 days and have been escalated.");
    }

    container.innerHTML = html || "<p style='color:white;'>No issues reported yet.</p>";
}


/* =======================================================
   EXECUTOR: PENDING ISSUES
======================================================= */

function loadPending() {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    const container = document.getElementById("pendingList");
    if (!container) return;

    let html = "";

    list.forEach((t, i) => {
        if (t.status === "Pending") {
            html += `
                <div class="issue-card">
                    <h3>Issue ${i + 1}</h3>
                    <p><b>Description:</b> ${t.text}</p>
                    <p><b>Location:</b> ${t.location}</p>
                    <p><b>Reported:</b> ${t.createdAt}</p>
                    <p><b>Status:</b> <span class="status-badge status-pending">${t.status}</span></p>
                    ${t.photo ? `<img src="${t.photo}" width="120" style="border-radius:8px;margin-top:5px;">` : ""}
                    <br><br>
                    <button class="login-btn" onclick="approveIssue(${i})">
                        Approve → Move to In-Progress
                    </button>
                </div>
            `;
        }
    });

    container.innerHTML = html || "<p style='color:white;'>No pending issues.</p>";
}

function approveIssue(index) {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    if (list[index]) {
        list[index].status = "In Progress";
        localStorage.setItem("tickets", JSON.stringify(list));
        alert("Issue approved and moved to In-Progress.");
        loadPending();
    }
}


/* =======================================================
   EXECUTOR: IN-PROGRESS ISSUES
======================================================= */

function loadInProgress() {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    const container = document.getElementById("inprogList");
    if (!container) return;

    let html = "";

    list.forEach((t, i) => {
        if (t.status === "In Progress") {
            html += `
                <div class="issue-card">
                    <h3>Issue ${i + 1}</h3>
                    <p><b>Description:</b> ${t.text}</p>
                    <p><b>Location:</b> ${t.location}</p>
                    <p><b>Reported:</b> ${t.createdAt}</p>
                    <p><b>Status:</b> <span class="status-badge status-inprogress">${t.status}</span></p>
                    ${t.photo ? `<img src="${t.photo}" width="120" style="border-radius:8px;margin-top:5px;">` : ""}
                    <br><br>
                    <button class="login-btn" style="background:#22c55e;"
                        onclick="completeIssue(${i})">
                        Mark Completed
                    </button>
                </div>
            `;
        }
    });

    container.innerHTML = html || "<p style='color:white;'>No issues in progress.</p>";
}

function completeIssue(index) {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    if (list[index]) {
        list[index].status = "Completed";
        localStorage.setItem("tickets", JSON.stringify(list));
        alert("Issue marked as Completed.");
        loadInProgress();
    }
}


/* =======================================================
   EXECUTOR: COMPLETED ISSUES
======================================================= */

function loadCompleted() {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    const container = document.getElementById("completedList");
    if (!container) return;

    let html = "";

    list.forEach((t, i) => {
        if (t.status === "Completed") {
            html += `
                <div class="issue-card">
                    <h3>Issue ${i + 1}</h3>
                    <p><b>Description:</b> ${t.text}</p>
                    <p><b>Location:</b> ${t.location}</p>
                    <p><b>Reported:</b> ${t.createdAt}</p>
                    <p><b>Status:</b> <span class="status-badge status-completed">${t.status}</span></p>
                    ${t.photo ? `<img src="${t.photo}" width="120" style="border-radius:8px;margin-top:5px;">` : ""}
                </div>
            `;
        }
    });

    container.innerHTML = html || "<p style='color:white;'>No completed issues yet.</p>";
}
