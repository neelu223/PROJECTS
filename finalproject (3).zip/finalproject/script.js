/* ================================================
   USER LOGIN
================================================= */
function userLogin() {
    const u = document.getElementById("user-name").value.trim();
    const p = document.getElementById("user-pass").value.trim();

    if (u === "user" && p === "1234") {
        window.location.href = "user-dashboard.html";
    } else {
        alert("Incorrect username or password!");
    }
}

/* ================================================
   EXECUTOR LOGIN + SAVE DEPARTMENT
================================================= */
function execLogin() {
    const u = document.getElementById("exec-name").value.trim();
    const p = document.getElementById("exec-pass").value.trim();
    const dept = document.getElementById("execDept").value;

    if (u === "executor" && p === "admin") {
        localStorage.setItem("executorDept", dept);
        window.location.href = "exec-dashboard.html";
    } else {
        alert("Incorrect executor login!");
    }
}

/* ================================================
   LOCATION
================================================= */
let placeName = "";

function getLocation() {
    const locText = document.getElementById("locationText");

    if (!navigator.geolocation) {
        alert("Geolocation not supported");
        return;
    }

    navigator.geolocation.getCurrentPosition(async pos => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;

        locText.textContent = "Detecting location...";

        try {
            const res = await fetch(
                `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`,
                { headers: { "User-Agent": "JanAnurodh/1.0" } }
            );

            const data = await res.json();
            placeName = data.display_name;
            locText.textContent = "📍 " + placeName;

        } catch {
            locText.textContent = "Failed to detect location";
        }
    });
}

/* ================================================
   PHOTO UPLOAD
================================================= */
function openPhotoUpload() {
    const input = document.getElementById("photoInput");
    const label = document.getElementById("photoName");

    input.click();
    input.onchange = () => {
        const f = input.files[0];
        label.textContent = f ? "Selected: " + f.name : "";
    };
}

/* ================================================
   VOICE INPUT
================================================= */
function startVoice() {
    if (!("webkitSpeechRecognition" in window)) {
        alert("Speech recognition not supported.");
        return;
    }

    const rec = new webkitSpeechRecognition();
    rec.lang = "en-IN";

    rec.onresult = e => {
        document.getElementById("problem").value =
            e.results[0][0].transcript;
    };

    rec.start();
}

/* ================================================
   SUBMIT REPORT (manual department)
================================================= */
function submitReport() {
    const issue = document.getElementById("problem").value.trim();
    const dept = document.getElementById("userDept").value;
    const photo = document.getElementById("photoInput").files[0];

    if (!issue) {
        alert("Please describe the issue.");
        return;
    }

    if (photo) {
        const r = new FileReader();
        r.onload = e => saveTicket(issue, dept, e.target.result);
        r.readAsDataURL(photo);
    } else {
        saveTicket(issue, dept, "");
    }
}

function saveTicket(text, dept, photoURL) {
    const now = new Date();

    const ticket = {
        id: Date.now(),
        text,
        department: dept,
        location: placeName || "Not Provided",
        status: "Pending",
        photo: photoURL,
        createdAt: now.toLocaleString()
    };

    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    list.push(ticket);
    localStorage.setItem("tickets", JSON.stringify(list));

    alert("Issue submitted to " + dept + " department!");
    window.location.href = "user-dashboard.html";
}

/* ================================================
   PAGE LOADERS
================================================= */
document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("pendingList")) loadPending();
    if (document.getElementById("inprogList")) loadInProgress();
    if (document.getElementById("completedList")) loadCompleted();
    if (document.getElementById("progressList")) loadUserProgress();
});

/* ================================================
   USER PROGRESS (NO FILTER)
================================================= */
function loadUserProgress() {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    const container = document.getElementById("progressList");
    let html = "";

    list.forEach((t, i) => {
        let badgeClass =
            t.status === "Pending" ? "status-pending" :
            t.status === "In Progress" ? "status-inprogress" :
            "status-completed";

        html += `
        <div class="issue-card">
            <h3>Issue ${i + 1}</h3>
            <p><b>Department:</b> ${t.department}</p>
            <p><b>Description:</b> ${t.text}</p>
            <p><b>Location:</b> ${t.location}</p>
            <p><b>Reported:</b> ${t.createdAt}</p>
            <p><b>Status:</b> <span class="status-badge ${badgeClass}">${t.status}</span></p>
            ${t.photo ? `<img src="${t.photo}" width="140" style="border-radius:10px;margin-top:8px;">` : ""}
        </div>`;
    });

    container.innerHTML = html || "<p>No issues reported yet.</p>";
}

/* ================================================
   EXECUTOR — LOAD DATA BY STATUS + DEPARTMENT FILTER
================================================= */

function loadPending() { loadByStatus("Pending", "pendingList"); }
function loadInProgress() { loadByStatus("In Progress", "inprogList"); }
function loadCompleted() { loadByStatus("Completed", "completedList"); }

function loadByStatus(status, containerId) {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    const dept = localStorage.getItem("executorDept");
    const container = document.getElementById(containerId);

    let html = "";

    list.forEach((t, i) => {
        if (t.status !== status) return;
        if (t.department !== dept) return;

        let badgeClass =
            t.status === "Pending" ? "status-pending" :
            t.status === "In Progress" ? "status-inprogress" :
            "status-completed";

        html += `
        <div class="issue-card">
            <h3>Issue ${i + 1}</h3>
            <p><b>Department:</b> ${t.department}</p>
            <p><b>Description:</b> ${t.text}</p>
            <p><b>Location:</b> ${t.location}</p>
            <p><b>Reported:</b> ${t.createdAt}</p>
            <p><b>Status:</b> 
                <span class="status-badge ${badgeClass}">${t.status}</span>
            </p>
            ${t.photo ? `<img src="${t.photo}" width="140" style="border-radius:10px;margin-top:8px;">` : ""}
        
            ${
                status === "Pending"
                    ? `<button class="login-btn" onclick="moveToProgress(${i})" style="margin-top:10px;">Move to In-Progress</button>`
                : status === "In Progress"
                    ? `<button class="login-btn" onclick="completeIssue(${i})" style="background:#22c55e;margin-top:10px;">Mark Completed</button>`
                : ""
            }
        </div>`;
    });

    container.innerHTML = html || "<p>No issues found.</p>";
}

/* ================================================
   EXECUTOR — ACTION BUTTONS
================================================= */

function moveToProgress(i) {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    list[i].status = "In Progress";
    localStorage.setItem("tickets", JSON.stringify(list));
    loadPending();
}

function completeIssue(i) {
    const list = JSON.parse(localStorage.getItem("tickets") || "[]");
    list[i].status = "Completed";
    localStorage.setItem("tickets", JSON.stringify(list));
    loadInProgress();
}
